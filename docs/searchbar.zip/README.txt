A Pen created at CodePen.io. You can find this one at https://codepen.io/fergustaylor/pen/qVgXxB.

 A simple demo showing how to use the datalist element.

Both standard and AJAX strategies used for populating datalist options.